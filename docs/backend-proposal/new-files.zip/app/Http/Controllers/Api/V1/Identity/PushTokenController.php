<?php

namespace App\Http\Controllers\Api\V1\Identity;

use App\Domain\Identity\Actions\RegisterDevicePushTokenAction;
use App\Domain\Identity\Models\PersonalAccessToken;
use App\Http\Controllers\Controller;
use App\Http\Requests\Api\V1\Identity\RegisterPushTokenRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class PushTokenController extends Controller
{
    /**
     * Register (or refresh) this phone for push notifications.
     */
    public function store(RegisterPushTokenRequest $request, RegisterDevicePushTokenAction $action): Response
    {
        /** @var User $user */
        $user = $request->user();
        /** @var PersonalAccessToken $accessToken */
        $accessToken = $user->currentAccessToken();

        $action->execute(
            $user,
            $accessToken,
            $request->string('token')->toString(),
            $request->string('platform')->toString(),
            $request->input('app_version'),
        );

        return response()->noContent();
    }

    /**
     * Stop notifications on this phone (the user switched them off).
     */
    public function destroy(Request $request, RegisterDevicePushTokenAction $action): Response
    {
        $validated = $request->validate(['token' => ['required', 'string', 'max:4096']]);

        /** @var User $user */
        $user = $request->user();
        $action->revoke($user, $validated['token']);

        return response()->noContent();
    }
}
