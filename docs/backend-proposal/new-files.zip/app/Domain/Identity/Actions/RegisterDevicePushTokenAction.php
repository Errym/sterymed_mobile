<?php

namespace App\Domain\Identity\Actions;

use App\Domain\Identity\Models\DevicePushToken;
use App\Domain\Identity\Models\PersonalAccessToken;
use App\Models\User;

class RegisterDevicePushTokenAction
{
    /**
     * Idempotent: the same device registering again just refreshes its row.
     * A phone handed to a colleague must never keep notifying the previous
     * person, so any other user's row for the same device token is removed
     * first.
     */
    public function execute(User $user, PersonalAccessToken $accessToken, string $token, string $platform, ?string $appVersion): DevicePushToken
    {
        DevicePushToken::query()->where('token', $token)->where('user_id', '!=', $user->id)->delete();

        return DevicePushToken::query()->updateOrCreate(
            ['token' => $token],
            [
                'user_id' => $user->id,
                'access_token_id' => $accessToken->id,
                'platform' => $platform,
                'app_version' => $appVersion,
                'last_registered_at' => now(),
            ],
        );
    }

    public function revoke(User $user, string $token): void
    {
        DevicePushToken::query()->where('token', $token)->where('user_id', $user->id)->delete();
    }
}
