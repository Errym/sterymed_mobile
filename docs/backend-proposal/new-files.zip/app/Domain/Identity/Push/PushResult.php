<?php

namespace App\Domain\Identity\Push;

enum PushResult
{
    case Sent;
    /** The token is dead (app uninstalled, token rotated): delete it. */
    case InvalidToken;
    /** Transient failure: keep the token, it will receive the next one. */
    case Failed;
}
