<?php

namespace App\Domain\Identity\Push;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/**
 * Firebase Cloud Messaging, HTTP v1. No SDK: a signed service-account JWT is
 * exchanged for a short-lived access token (cached), then one POST per device.
 *
 * Configuration (config/push.php): FCM_PROJECT_ID and FCM_SERVICE_ACCOUNT
 * (path to the service-account JSON, or that JSON base64-encoded).
 */
final class FcmPushSender implements PushSender
{
    private const SCOPE = 'https://www.googleapis.com/auth/firebase.messaging';

    public function send(string $deviceToken, string $platform, PushMessage $message): PushResult
    {
        $projectId = config('push.fcm.project_id');

        try {
            $response = Http::withToken($this->accessToken())
                ->timeout(10)
                ->post("https://fcm.googleapis.com/v1/projects/{$projectId}/messages:send", [
                    'message' => $this->payload($deviceToken, $platform, $message),
                ]);
        } catch (Throwable $e) {
            Log::warning('push.fcm_unreachable', ['error' => $e->getMessage()]);

            return PushResult::Failed;
        }

        if ($response->successful()) {
            return PushResult::Sent;
        }

        $status = (string) $response->json('error.status');
        $detail = collect($response->json('error.details', []))->pluck('errorCode')->filter()->implode(',');

        // UNREGISTERED: the app was uninstalled or the token rotated.
        // INVALID_ARGUMENT naming the registration token: it was never valid.
        if ($response->status() === 404 || $status === 'NOT_FOUND' || str_contains($detail, 'UNREGISTERED')
            || ($status === 'INVALID_ARGUMENT' && str_contains((string) $response->body(), 'registration token'))) {
            return PushResult::InvalidToken;
        }

        Log::warning('push.fcm_rejected', ['status' => $response->status(), 'fcm_status' => $status]);

        return PushResult::Failed;
    }

    /**
     * @return array<string, mixed>
     */
    private function payload(string $deviceToken, string $platform, PushMessage $message): array
    {
        $payload = [
            'token' => $deviceToken,
            'notification' => ['title' => $message->title, 'body' => $message->body],
            'data' => $message->data,
        ];

        if ($platform === 'android') {
            $payload['android'] = [
                'priority' => 'HIGH',
                'notification' => ['channel_id' => 'alerts'],
            ];
        } else {
            $payload['apns'] = ['payload' => ['aps' => ['sound' => 'default']]];
        }

        return $payload;
    }

    private function accessToken(): string
    {
        return Cache::remember('push:fcm_access_token', 3000, function (): string {
            $account = $this->serviceAccount();
            $now = time();
            $claims = [
                'iss' => $account['client_email'],
                'scope' => self::SCOPE,
                'aud' => $account['token_uri'] ?? 'https://oauth2.googleapis.com/token',
                'iat' => $now,
                'exp' => $now + 3600,
            ];

            $response = Http::asForm()->timeout(10)->post($claims['aud'], [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $this->jwt($claims, $account['private_key']),
            ]);

            if (! $response->successful() || ! $response->json('access_token')) {
                throw new RuntimeException('FCM authentication failed: '.$response->status());
            }

            return (string) $response->json('access_token');
        });
    }

    /**
     * @param  array<string, mixed>  $claims
     */
    private function jwt(array $claims, string $privateKey): string
    {
        $b64 = fn (string $s) => rtrim(strtr(base64_encode($s), '+/', '-_'), '=');
        $signingInput = $b64((string) json_encode(['alg' => 'RS256', 'typ' => 'JWT'])).'.'.$b64((string) json_encode($claims));

        if (! openssl_sign($signingInput, $signature, $privateKey, OPENSSL_ALGO_SHA256)) {
            throw new RuntimeException('Could not sign the FCM assertion.');
        }

        return $signingInput.'.'.$b64($signature);
    }

    /**
     * @return array{client_email: string, private_key: string, token_uri?: string}
     */
    private function serviceAccount(): array
    {
        $raw = (string) config('push.fcm.service_account');
        $json = is_file($raw) ? (string) file_get_contents($raw) : (string) base64_decode($raw, true);
        $account = json_decode($json, true);

        if (! is_array($account) || empty($account['client_email']) || empty($account['private_key'])) {
            throw new RuntimeException('FCM_SERVICE_ACCOUNT is missing or is not a service-account key.');
        }

        return $account;
    }
}
