<?php

namespace App\Domain\Identity\Push;

/** Push is switched off (PUSH_DRIVER=none): tokens are kept, nothing leaves. */
final class NullPushSender implements PushSender
{
    public function send(string $deviceToken, string $platform, PushMessage $message): PushResult
    {
        return PushResult::Sent;
    }
}
