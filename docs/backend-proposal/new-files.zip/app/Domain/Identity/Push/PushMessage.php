<?php

namespace App\Domain\Identity\Push;

/**
 * What a phone is told. Deliberately generic: a notification can be read on a
 * locked screen, so it never carries a patient reference, a product name or
 * any clinical detail. The app fetches the details after the user opens it.
 */
final readonly class PushMessage
{
    /**
     * @param  array<string, string>  $data  string values only (FCM requirement)
     */
    public function __construct(
        public string $title,
        public string $body,
        public array $data = [],
    ) {}
}
