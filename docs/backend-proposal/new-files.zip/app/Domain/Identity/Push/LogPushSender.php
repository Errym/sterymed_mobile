<?php

namespace App\Domain\Identity\Push;

use Illuminate\Support\Facades\Log;

/** Local development: shows what would be sent, without a Firebase project. */
final class LogPushSender implements PushSender
{
    public function send(string $deviceToken, string $platform, PushMessage $message): PushResult
    {
        Log::info('push.sent', [
            'platform' => $platform,
            'token_tail' => substr($deviceToken, -6),
            'title' => $message->title,
            'body' => $message->body,
            'data' => $message->data,
        ]);

        return PushResult::Sent;
    }
}
