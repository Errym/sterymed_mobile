<?php

namespace App\Domain\Identity\Push;

interface PushSender
{
    public function send(string $deviceToken, string $platform, PushMessage $message): PushResult;
}
