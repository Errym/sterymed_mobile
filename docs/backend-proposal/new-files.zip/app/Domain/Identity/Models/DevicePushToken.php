<?php

namespace App\Domain\Identity\Models;

use App\Models\User;
use App\Support\Concerns\BelongsToTenant;
use App\Support\Concerns\HasUuidv7;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;

/**
 * @property string $id
 * @property string $tenant_id
 * @property string $user_id
 * @property int $access_token_id
 * @property string $token
 * @property string $platform
 * @property string|null $app_version
 * @property Carbon $last_registered_at
 */
class DevicePushToken extends Model
{
    use BelongsToTenant;
    use HasUuidv7;

    protected $fillable = [
        'tenant_id', 'user_id', 'access_token_id', 'token', 'platform',
        'app_version', 'last_registered_at',
    ];

    protected function casts(): array
    {
        return ['last_registered_at' => 'datetime'];
    }

    /**
     * @return BelongsTo<User, $this>
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
