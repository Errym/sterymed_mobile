<?php

namespace App\Domain\Inventory\Actions;

use App\Domain\Inventory\Jobs\SendAlertPushDigestJob;
use App\Domain\Inventory\Models\Alert;
use Illuminate\Support\Facades\Cache;

/**
 * Called when an alert row is created. The first alert of a burst schedules
 * ONE delayed digest job; the others that arrive inside the window just ride
 * on it, so the people who must act get a single, accurate notification.
 */
class SchedulePushForNewAlertAction
{
    public function execute(Alert $alert): void
    {
        if (config('push.driver') === 'none') {
            return;
        }

        // The delay also lets the transaction that raised the alert commit
        // before the job reads it (so it is clamped, never zero, in production).
        $delay = (int) config('push.digest_delay_seconds');

        // Held a little longer than the delay; the job releases it when it starts.
        if (! Cache::add(SendAlertPushDigestJob::lockKey($alert->tenant_id), 1, $delay + 15)) {
            return;
        }

        SendAlertPushDigestJob::dispatch($alert->tenant_id)->delay(now()->addSeconds($delay));
    }
}
