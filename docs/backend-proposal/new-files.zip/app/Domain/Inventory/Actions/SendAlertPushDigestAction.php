<?php

namespace App\Domain\Inventory\Actions;

use App\Domain\Identity\Models\DevicePushToken;
use App\Domain\Identity\Push\PushMessage;
use App\Domain\Identity\Push\PushResult;
use App\Domain\Identity\Push\PushSender;
use App\Domain\Inventory\Enums\AlertSeverity;
use App\Domain\Inventory\Enums\AlertState;
use App\Domain\Inventory\Models\Alert;
use App\Domain\Tenancy\Models\Tenant;
use App\Support\Tenancy\TenantContext;
use Illuminate\Support\Facades\DB;

/**
 * Tells the phones of the people who may see alerts that new ones were raised.
 *
 * - One notification per phone, however many alerts were raised (the hourly
 *   detection can open dozens).
 * - Each alert is announced once (alerts.push_sent_at).
 * - Only members whose CURRENT role holds alerts.view are notified, and only
 *   on phones whose login is still valid.
 * - The text is generic by design (no product, batch or patient) because a
 *   notification is readable on a locked screen.
 */
class SendAlertPushDigestAction
{
    public function __construct(private PushSender $sender) {}

    /**
     * @return int number of phones the notification was handed to
     */
    public function execute(Tenant $tenant): int
    {
        /** @var array{message: PushMessage, tokens: array<int, array{id: string, token: string, platform: string}>}|null $plan */
        $plan = TenantContext::run($tenant, fn () => $this->plan());

        if ($plan === null) {
            return 0;
        }

        $sent = 0;
        foreach ($plan['tokens'] as $device) {
            $result = $this->sender->send($device['token'], $device['platform'], $plan['message']);

            if ($result === PushResult::Sent) {
                $sent++;
            } elseif ($result === PushResult::InvalidToken) {
                TenantContext::run($tenant, fn () => DevicePushToken::query()->whereKey($device['id'])->delete());
            }
        }

        return $sent;
    }

    /**
     * @return array{message: PushMessage, tokens: array<int, array{id: string, token: string, platform: string}>}|null
     */
    private function plan(): ?array
    {
        $alerts = Alert::query()
            ->where('state', AlertState::Open)
            ->whereNull('push_sent_at')
            ->get();

        if ($alerts->isEmpty()) {
            return null;
        }

        // Claimed before sending: a retry or a second worker must not announce
        // the same alerts twice.
        Alert::query()->whereKey($alerts->modelKeys())->update(['push_sent_at' => now()]);

        $tokens = DevicePushToken::query()
            ->join('personal_access_tokens as t', 't.id', '=', 'device_push_tokens.access_token_id')
            ->where(fn ($q) => $q->whereNull('t.expires_at')->orWhere('t.expires_at', '>', now()))
            ->select('device_push_tokens.*')
            ->with('user')
            ->get()
            ->filter(fn (DevicePushToken $row) => $row->user !== null && $row->user->can('alerts.view'))
            ->map(fn (DevicePushToken $row) => ['id' => $row->id, 'token' => $row->token, 'platform' => $row->platform])
            ->values()
            ->all();

        if ($tokens === []) {
            return null;
        }

        return ['message' => $this->message($alerts), 'tokens' => $tokens];
    }

    /**
     * @param  \Illuminate\Support\Collection<int, Alert>  $alerts
     */
    private function message($alerts): PushMessage
    {
        $total = $alerts->count();
        $critical = $alerts->filter(fn (Alert $a) => $a->severity === AlertSeverity::Critical)->count();

        $body = match (true) {
            $total === 1 && $critical === 1 => '1 alerte critique à traiter',
            $total === 1 => '1 nouvelle alerte',
            $critical > 0 => "{$total} nouvelles alertes dont {$critical} critique".($critical > 1 ? 's' : ''),
            default => "{$total} nouvelles alertes",
        };

        return new PushMessage('SteryMed', $body, [
            'type' => 'alerts',
            'route' => '/app/alerts',
            'critical' => (string) $critical,
        ]);
    }
}
