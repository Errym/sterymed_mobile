<?php

namespace App\Domain\Inventory\Jobs;

use App\Domain\Inventory\Actions\SendAlertPushDigestAction;
use App\Domain\Tenancy\Models\Tenant;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Queue\Queueable;
use Illuminate\Support\Facades\Cache;

class SendAlertPushDigestJob implements ShouldQueue
{
    use Queueable;

    public int $tries = 2;

    public function __construct(public string $tenantId) {}

    public static function lockKey(string $tenantId): string
    {
        return "push-digest:{$tenantId}";
    }

    public function handle(SendAlertPushDigestAction $action): void
    {
        // Released first: an alert raised while this runs schedules the next digest.
        Cache::forget(self::lockKey($this->tenantId));

        $tenant = Tenant::query()->find($this->tenantId);

        if ($tenant !== null) {
            $action->execute($tenant);
        }
    }
}
