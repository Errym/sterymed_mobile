<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

/**
 * Mobile push notifications. A device token belongs to the login token that
 * registered it: signing out, "sign out everywhere" or a revoked token deletes
 * the personal_access_tokens row, and the cascade removes the push token, so a
 * device that was signed out never receives another notification.
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::create('device_push_tokens', function (Blueprint $table) {
            $table->uuid('id')->primary()->default(DB::raw('uuidv7()'));
            $table->foreignUuid('tenant_id')->constrained()->cascadeOnDelete();
            $table->foreignUuid('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('access_token_id')->constrained('personal_access_tokens')->cascadeOnDelete();
            $table->string('token', 4096);
            $table->string('platform', 16);
            $table->string('app_version', 32)->nullable();
            $table->timestampTz('last_registered_at');
            $table->timestamps();

            // One row per device token per practice; a device re-registering
            // updates it instead of piling up duplicates.
            $table->unique(['tenant_id', 'token']);
            $table->index(['tenant_id', 'user_id']);
        });

        DB::statement('ALTER TABLE device_push_tokens ENABLE ROW LEVEL SECURITY');
        DB::statement('ALTER TABLE device_push_tokens FORCE ROW LEVEL SECURITY');
        DB::statement(<<<'SQL'
            CREATE POLICY tenant_isolation ON device_push_tokens
                USING (tenant_id = current_setting('app.tenant_id', true)::uuid)
                WITH CHECK (tenant_id = current_setting('app.tenant_id', true)::uuid)
            SQL);

        // Lets the digest job send each alert exactly once.
        Schema::table('alerts', function (Blueprint $table) {
            $table->timestampTz('push_sent_at')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('alerts', function (Blueprint $table) {
            $table->dropColumn('push_sent_at');
        });
        Schema::dropIfExists('device_push_tokens');
    }
};
