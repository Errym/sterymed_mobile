<?php

use App\Domain\Identity\Actions\SeedTenantRolesAction;
use App\Domain\Identity\Enums\TenantRole;
use App\Domain\Identity\Models\DevicePushToken;
use App\Domain\Identity\Models\TenantUser;
use App\Domain\Identity\Push\PushMessage;
use App\Domain\Identity\Push\PushResult;
use App\Domain\Identity\Push\PushSender;
use App\Domain\Inventory\Actions\SendAlertPushDigestAction;
use App\Domain\Inventory\Enums\AlertSeverity;
use App\Domain\Inventory\Enums\AlertState;
use App\Domain\Inventory\Enums\AlertType;
use App\Domain\Inventory\Jobs\SendAlertPushDigestJob;
use App\Domain\Inventory\Models\Alert;
use App\Domain\Tenancy\Models\Tenant;
use App\Models\User;
use App\Support\Tenancy\TenantContext;
use App\Support\Tenancy\TenantScope;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Spatie\Permission\PermissionRegistrar;

final class RecordingPushSender implements PushSender
{
    /** @var array<int, array{token: string, platform: string, message: PushMessage}> */
    public array $sent = [];

    public function send(string $deviceToken, string $platform, PushMessage $message): PushResult
    {
        $this->sent[] = ['token' => $deviceToken, 'platform' => $platform, 'message' => $message];

        return PushResult::Sent;
    }
}

function pushRecorder(): RecordingPushSender
{
    $recorder = new RecordingPushSender;
    app()->instance(PushSender::class, $recorder);

    return $recorder;
}

function pushMember(?Tenant $tenant = null, TenantRole $role = TenantRole::StockManager): array
{
    $tenant ??= Tenant::create(['name' => 'Cabinet Push', 'slug' => 'push-'.Str::lower(Str::random(10))]);
    $user = User::create([
        'name' => 'Membre '.Str::random(4),
        'email' => 'm-'.Str::lower(Str::random(10)).'@example.com',
        'password' => Hash::make('correct-password'),
    ]);
    TenantUser::create(['tenant_id' => $tenant->id, 'user_id' => $user->id, 'status' => 'active']);

    app(SeedTenantRolesAction::class)->execute($tenant);
    $registrar = app(PermissionRegistrar::class);
    $registrar->setPermissionsTeamId($tenant->id);
    $user->assignRole($role->value);
    $registrar->setPermissionsTeamId(null);

    return [$tenant, $user];
}

function pushLogin(Tenant $tenant, User $user): string
{
    return test()->postJson('/api/v1/auth/login', [
        'tenant_slug' => $tenant->slug,
        'email' => $user->email,
        'password' => 'correct-password',
    ], ['Idempotency-Key' => (string) Str::uuid()])->json('token');
}

function pushRegister(string $bearer, string $token, string $platform = 'android')
{
    return test()->withToken($bearer)->postJson('/api/v1/push-tokens', [
        'token' => $token,
        'platform' => $platform,
        'app_version' => '1.0.0+1',
    ], ['Idempotency-Key' => (string) Str::uuid()]);
}

function pushRaiseAlert(Tenant $tenant, AlertSeverity $severity = AlertSeverity::Warning): Alert
{
    return TenantContext::run($tenant, fn () => Alert::create([
        'tenant_id' => $tenant->id,
        'type' => AlertType::LowStock,
        'severity' => $severity,
        'state' => AlertState::Open,
        'subject_type' => 'App\\Domain\\Catalog\\Models\\Product',
        'subject_id' => (string) Str::uuid(),
        'message' => 'Stock for "Gants" is below threshold (2/10).',
    ]));
}

function pushTokensOf(Tenant $tenant): int
{
    return DevicePushToken::withoutGlobalScope(TenantScope::class)->where('tenant_id', $tenant->id)->count();
}

beforeEach(function () {
    Cache::flush();
    config(['push.driver' => 'log', 'push.digest_delay_seconds' => 0]);
});

test('a phone registers once, however often it says so', function () {
    [$tenant, $user] = pushMember();
    $bearer = pushLogin($tenant, $user);

    pushRegister($bearer, str_repeat('a', 40))->assertNoContent();
    pushRegister($bearer, str_repeat('a', 40))->assertNoContent();

    expect(pushTokensOf($tenant))->toBe(1);
});

test('a bad token or platform is refused with 422', function () {
    [$tenant, $user] = pushMember();
    $bearer = pushLogin($tenant, $user);

    pushRegister($bearer, 'short')->assertStatus(422);
    pushRegister($bearer, str_repeat('a', 40), 'windows')->assertStatus(422);
});

test('registering needs a signed-in member', function () {
    test()->postJson('/api/v1/push-tokens', ['token' => str_repeat('a', 40), 'platform' => 'android'], [
        'Idempotency-Key' => (string) Str::uuid(),
    ])->assertStatus(401);
});

test('a phone handed to a colleague stops notifying the previous person', function () {
    [$tenant, $first] = pushMember();
    [, $second] = pushMember($tenant, TenantRole::Practitioner);

    pushRegister(pushLogin($tenant, $first), str_repeat('d', 40))->assertNoContent();
    pushRegister(pushLogin($tenant, $second), str_repeat('d', 40))->assertNoContent();

    $rows = DevicePushToken::withoutGlobalScope(TenantScope::class)->where('tenant_id', $tenant->id)->get();
    expect($rows)->toHaveCount(1)->and($rows->first()->user_id)->toBe($second->id);
});

test('switching notifications off removes only that phone', function () {
    [$tenant, $user] = pushMember();
    $bearer = pushLogin($tenant, $user);
    pushRegister($bearer, str_repeat('a', 40));
    pushRegister($bearer, str_repeat('b', 40));

    test()->withToken($bearer)->deleteJson('/api/v1/push-tokens', ['token' => str_repeat('a', 40)])->assertNoContent();

    expect(pushTokensOf($tenant))->toBe(1);
});

test('signing out deletes the phone so it never hears from the practice again', function () {
    [$tenant, $user] = pushMember();
    $bearer = pushLogin($tenant, $user);
    pushRegister($bearer, str_repeat('a', 40));

    test()->withToken($bearer)->deleteJson('/api/v1/auth/logout')->assertNoContent();

    expect(pushTokensOf($tenant))->toBe(0);
});

test('a new alert notifies a member with alerts.view, with generic text only', function () {
    $push = pushRecorder();
    [$tenant, $user] = pushMember();
    pushRegister(pushLogin($tenant, $user), str_repeat('a', 40));

    pushRaiseAlert($tenant, AlertSeverity::Critical);

    expect($push->sent)->toHaveCount(1);
    $message = $push->sent[0]['message'];
    expect($message->body)->toBe('1 alerte critique à traiter')
        ->and($message->data['route'])->toBe('/app/alerts')
        // Nothing clinical on a lock screen.
        ->and(json_encode($message))->not->toContain('Gants');
});

test('a burst of alerts is one notification per phone, and each alert is announced once', function () {
    $push = pushRecorder();
    [$tenant, $user] = pushMember();
    pushRegister(pushLogin($tenant, $user), str_repeat('a', 40));

    // The real queue delays the digest; here the queue is held so the three
    // alerts all land inside one window.
    Queue::fake();
    pushRaiseAlert($tenant);
    pushRaiseAlert($tenant);
    pushRaiseAlert($tenant, AlertSeverity::Critical);

    Queue::assertPushed(SendAlertPushDigestJob::class, 1);

    $action = app(SendAlertPushDigestAction::class);
    expect($action->execute($tenant))->toBe(1);
    // Nothing new: announcing again sends nothing.
    expect($action->execute($tenant))->toBe(0);

    expect($push->sent)->toHaveCount(1)
        ->and($push->sent[0]['message']->body)->toBe('3 nouvelles alertes dont 1 critique');
});

test('a member who no longer holds a role with alerts.view is not notified', function () {
    $push = pushRecorder();
    [$tenant, $user] = pushMember();
    pushRegister(pushLogin($tenant, $user), str_repeat('a', 40));

    $registrar = app(PermissionRegistrar::class);
    $registrar->setPermissionsTeamId($tenant->id);
    $user->syncRoles([]);
    $registrar->setPermissionsTeamId(null);

    pushRaiseAlert($tenant);

    expect($push->sent)->toBeEmpty();
});

test('a practice never notifies another practice\'s phones', function () {
    $push = pushRecorder();
    [$tenantA, $userA] = pushMember();
    [$tenantB, $userB] = pushMember();
    pushRegister(pushLogin($tenantA, $userA), str_repeat('a', 40));
    pushRegister(pushLogin($tenantB, $userB), str_repeat('b', 40));

    pushRaiseAlert($tenantA);

    expect(collect($push->sent)->pluck('token')->all())->toBe([str_repeat('a', 40)]);
});

test('with push switched off nothing is sent but tokens are still kept', function () {
    config(['push.driver' => 'none']);
    $push = pushRecorder();
    [$tenant, $user] = pushMember();
    pushRegister(pushLogin($tenant, $user), str_repeat('a', 40));

    pushRaiseAlert($tenant);

    expect($push->sent)->toBeEmpty()->and(pushTokensOf($tenant))->toBe(1);
});

test('the log driver writes what would be sent', function () {
    config(['push.driver' => 'log']);
    $captured = [];
    Log::listen(function ($event) use (&$captured) {
        if ($event->message === 'push.sent') {
            $captured[] = $event->context;
        }
    });
    [$tenant, $user] = pushMember();
    pushRegister(pushLogin($tenant, $user), str_repeat('a', 40));

    pushRaiseAlert($tenant);

    expect($captured)->toHaveCount(1)->and($captured[0]['body'])->toBe('1 nouvelle alerte');
});

test('FCM: a dead token is deleted, a working one is sent, authentication is cached', function () {
    $key = openssl_pkey_new(['private_key_bits' => 2048, 'private_key_type' => OPENSSL_KEYTYPE_RSA]);
    openssl_pkey_export($key, $pem);
    config([
        'push.driver' => 'fcm',
        'push.fcm.project_id' => 'demo-project',
        'push.fcm.service_account' => base64_encode(json_encode([
            'client_email' => 'push@demo-project.iam.gserviceaccount.com',
            'private_key' => $pem,
            'token_uri' => 'https://oauth2.googleapis.com/token',
        ])),
    ]);

    Http::fake([
        'oauth2.googleapis.com/*' => Http::response(['access_token' => 'ya29.test', 'expires_in' => 3600]),
        'fcm.googleapis.com/*' => Http::sequence()
            ->push(['name' => 'projects/demo-project/messages/1'], 200)
            ->push(['error' => ['status' => 'NOT_FOUND', 'details' => [['errorCode' => 'UNREGISTERED']]]], 404),
    ]);

    [$tenant, $user] = pushMember();
    $bearer = pushLogin($tenant, $user);
    pushRegister($bearer, str_repeat('a', 40));
    pushRegister($bearer, str_repeat('b', 40), 'ios');

    pushRaiseAlert($tenant);

    // Two phones: one accepted, one reported as unregistered and therefore removed.
    expect(pushTokensOf($tenant))->toBe(1);
    Http::assertSentCount(3); // 1 auth + 2 sends
    Http::assertSent(fn ($request) => str_contains($request->url(), 'messages:send')
        && $request->hasHeader('Authorization', 'Bearer ya29.test')
        && isset($request['message']['notification']['body'])
        && ! str_contains(json_encode($request->data()), 'Gants'));
});
