<?php

return [

    /*
    | Public self-serve sign-up (POST /api/v1/tenants).
    |
    | On by default so development and demos work. A pilot or production
    | server hosts known clinics only: set STERIQORE_REGISTRATION_ENABLED=false
    | there (turn it on briefly to create the pilot practice, then off again),
    | otherwise anyone who finds the address can create practices.
    */
    'enabled' => (bool) env('STERIQORE_REGISTRATION_ENABLED', true),

];
