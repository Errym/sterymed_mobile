<?php

return [

    /*
    | How mobile push notifications leave the server.
    |   none : nothing is sent (default; tokens are still stored)
    |   log  : written to the application log (local development)
    |   fcm  : Firebase Cloud Messaging HTTP v1 (staging / production)
    */
    'driver' => env('PUSH_DRIVER', 'none'),

    /*
    | Alerts raised within this many seconds are sent as ONE notification, so
    | the hourly detection never buzzes a phone ten times.
    */
    'digest_delay_seconds' => (int) env('PUSH_DIGEST_DELAY_SECONDS', 30),

    'fcm' => [
        'project_id' => env('FCM_PROJECT_ID'),
        // Either an absolute path to the service-account JSON file, or the
        // JSON itself base64-encoded (convenient for a secret manager).
        'service_account' => env('FCM_SERVICE_ACCOUNT'),
    ],

];
